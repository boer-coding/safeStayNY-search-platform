
CREATE TABLE host (
    host_id   	INT,
    host_name   VARCHAR(25),
	PRIMARY KEY (host_id)
);

CREATE TABLE nbhood_group (
    group_id    INT,
    group_name 	VARCHAR(20),
	PRIMARY KEY (group_id)
);

CREATE TABLE nbhood (
    nbhood_name   VARCHAR(50),
    group_id      INT,
	PRIMARY KEY (nbhood_name, group_id),
	FOREIGN KEY (group_id) REFERENCES nbhood_group(group_id)
);

CREATE TABLE review (
    review_id          		INT,
    review_num         		INT,
    review_rating      		DECIMAL(3, 2),
    review_accuracy    		DECIMAL(3, 2),
    review_clean	 		DECIMAL(3, 2),
    review_checkin      	DECIMAL(3, 2),
    review_communication 	DECIMAL(3, 2),
    review_location 		DECIMAL(3, 2),
    review_value 			DECIMAL(3, 2),
    review_pmonth 			DECIMAL(3, 2),
	PRIMARY KEY (review_id)
);

CREATE TABLE airbnb (
    listing_id    	INT,
    description 	VARCHAR(120),
    host_id			INT,
    room_type		ENUM ('Entire home/apt', 'Private room','Hotel room','Shared room'), 
    price			INT,
    mini_nights 	INT,
    group_id		INT,
    nbhood_name     VARCHAR(30),
	latitude       	DECIMAL(10, 8),
	longitude      	DECIMAL(10, 8),	
	review_id 		INT,
	PRIMARY KEY (listing_id),
	FOREIGN KEY (host_id) REFERENCES host(host_id),
	FOREIGN KEY (group_id) REFERENCES nbhood_group (group_id),
	FOREIGN KEY (nbhood_name) REFERENCES nbhood (nbhood_name),
	FOREIGN KEY (review_id) REFERENCES review (review_id),
);

