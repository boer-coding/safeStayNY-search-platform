CREATE TABLE OFNS_DESC (
    ky_cd    INT,
    ofns_type VARCHAR(60)	NOT NULL,
	PRIMARY KEY (ky_cd)
);

CREATE TABLE PD_DESC (
    pd_cd    INT,
    pd_type VARCHAR(60),
	PRIMARY KEY (pd_cd)
);

CREATE TABLE person_type (
    type_id     INT,
    age_group   ENUM ('<18','18-24','25-44','45-64','65+')      	  NOT NULL, 
	gender 		ENUM ('F', 'M','U')									  NOT NULL, 
	race        ENUM ('BLACK', 'WHITE','WHITE HISPANIC',
						'BLACK HISPANIC','ASIAN / PACIFIC ISLANDER',
						'UNKNOWN','AMERICAN INDIAN/ALASKAN NATIVE')   NOT NULL, 
	PRIMARY KEY (id)
);

CREATE TABLE arrest_list (
    arrest_id      INT,
	arrest_date    DATE 			NOT NULL,
	latitude       DECIMAL(8, 6)	NOT NULL,
	longitude      DECIMAL(8, 6)	NOT NULL,
	type_id		   INT				NOT NULL,
	ky_cd          INT,
	pd_cd          INT				NOT NULL,
	PRIMARY KEY (arrest_id),
	FOREIGN KEY (ky_cd) REFERENCES OFNS_DESC (ky_cd),
	FOREIGN KEY (pd_cd) REFERENCES PD_DESC (pd_cd),
	FOREIGN KEY (type_id) REFERENCES person_type (type_id),
);


