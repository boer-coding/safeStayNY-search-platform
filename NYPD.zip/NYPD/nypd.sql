CREATE TABLE OFNS_DESC (
    ky_cd    INT,
    ofns_type VARCHAR(60),
    
	PRIMARY KEY (ky_cd)
);

CREATE TABLE PD_DESC (
    pd_cd    INT,
    pd_type VARCHAR(60),

	PRIMARY KEY (pd_cd)
);

CREATE TABLE NYPD_Arrest (
    arrest_id      INT,
	arrest_date    DATE,
	latitude       DECIMAL(10, 8),
	longitude      DECIMAL(10, 8),
	age_group      ENUM ('<18', '18-24','25-44','45-64','65+'), 
	gender 		   ENUM ('F', 'M','U'), 
	race           ENUM ('BLACK', 'WHITE','WHITE HISPANIC','BLACK HISPANIC','ASIAN / PACIFIC ISLANDER','UNKNOWN','AMERICAN INDIAN/ALASKAN NATIVE'), 
	ky_cd          INT,
	pd_cd          INT,

	PRIMARY KEY (arrest_id),
	FOREIGN KEY (ky_cd) REFERENCES OFNS_DESC (ky_cd),
	FOREIGN KEY (pd_cd) REFERENCES PD_DESC (pd_cd),

	)